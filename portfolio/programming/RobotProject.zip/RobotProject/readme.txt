By Kristin Yin and Chengcheng Zhao

to run the game download python2 and pygame

download python2(32-bit):
https://www.python.org/downloads/release/python-2710/ 

download pygame:
http://pygame.org/download.shtml

run the game by running the main.py file in a command line in the src folder.