This is a Pokemon Tower Defense game coded in python with Pygame.
To run the game python2 is also required instead of python3.
Pygame can be downlaoded here: http://www.pygame.org/download.shtml
In order to run the game, simply run the PokemonTowerDefense.py file.



All images and data from bulbapedia.bulbagarden.net/, but photoshoped for the game.
Map was photoshoped using tiles method from actual game map images, 
so it is not an actual route/map from a Pokemon game.

Font from:http://www.fonts2u.com/pokemon-pixel-font-regular.font

