Twitterbot created for an art project that generates sea creatures.
Used tweepy library to access Twitter API: http://www.tweepy.org/

Change consumer and access codes to access own twitter account and generate unknown sea creatures!

Check out my Twitterbot: https://twitter.com/seaLifeExpert